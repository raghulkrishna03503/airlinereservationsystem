package com.gui;

import com.gui.sign.SignIn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GUI {
    ImageIcon logo = new ImageIcon("D:\\Object Oriented Programming\\Mini Project\\AirlineReservationSystem\\images\\logo.png");
    JLabel logoLabel = new JLabel("", SwingConstants.CENTER);
    JLabel titleLabel = new JLabel("Airline Reservation System", SwingConstants.CENTER);
    JLabel developedByLabel = new JLabel("Developed by Logica Infinitum", SwingConstants.CENTER);
    JLabel signInLabel = new JLabel("", SwingConstants.CENTER);
    JLabel emailIdLabel = new JLabel("Email ID: ", SwingConstants.LEADING);
    JLabel passWordLabel = new JLabel("Password: ", SwingConstants.LEADING);
    JButton userButton = new JButton("User");
    JButton adminButton = new JButton("Admin");
    JButton submitButton = new JButton("Sign In");
    JButton forgotButton = new JButton("Forgot Password?? Click here");
    JButton registerButton = new JButton("New User?? Click here");
    JTextField emailIdEntry = new JTextField(20);
    JTextField passWordEntry = new JTextField(20);
    JFrame frame = new JFrame("Airline Reservation System");
    JPanel mainPanel = new JPanel();
    String regex = "^(.+)@(.+)$";
    Pattern emailPattern = Pattern.compile(regex);
    Matcher emailMatcher;
    JFrame home = new JFrame("Home - Airline Reservation System");
    public GUI(){
        // Fonts
        Font fontArial20 = new Font("Arial", Font.BOLD, 20);
        Font fontArial15 = new Font("Arial", Font.BOLD, 15);
        Font fontArial10 = new Font("Arial", Font.BOLD, 10);

        // Labels
        logoLabel.setIcon(logo);
        titleLabel.setFont(fontArial20);
        titleLabel.setForeground(Color.BLACK);
        developedByLabel.setFont(fontArial10);
        developedByLabel.setForeground(Color.BLACK);
        signInLabel.setForeground(Color.BLACK);
        signInLabel.setFont(fontArial20);
        emailIdLabel.setForeground(Color.BLACK);
        emailIdLabel.setFont(fontArial15);
        passWordLabel.setForeground(Color.BLACK);
        passWordLabel.setFont(fontArial15);

        // Buttons
        userButton.setFont(fontArial15);
        userButton.setBackground(Color.ORANGE);
        userButton.setForeground(Color.BLACK);
        userButton.setFocusable(false);
        userButton.setBorderPainted(false);
        adminButton.setFont(fontArial15);
        adminButton.setBackground(Color.ORANGE);
        adminButton.setForeground(Color.BLACK);
        adminButton.setFocusable(false);
        adminButton.setBorderPainted(false);
        submitButton.setFont(fontArial15);
        submitButton.setBackground(Color.ORANGE);
        submitButton.setForeground(Color.BLACK);
        submitButton.setFocusable(false);
        submitButton.setBorderPainted(false);
        forgotButton.setFont(fontArial15);
        forgotButton.setBackground(Color.LIGHT_GRAY);
        forgotButton.setForeground(Color.BLACK);
        forgotButton.setFocusable(false);
        forgotButton.setBorderPainted(false);
        registerButton.setFont(fontArial15);
        registerButton.setBackground(Color.LIGHT_GRAY);
        registerButton.setForeground(Color.BLACK);
        registerButton.setFocusable(false);
        registerButton.setBorderPainted(false);

        // Panel
        mainPanel.setLayout(new FlowLayout(FlowLayout.CENTER,40,20));
        mainPanel.setBackground(Color.LIGHT_GRAY);
        mainPanel.add(logoLabel);
        mainPanel.add(titleLabel);
        mainPanel.add(userButton);
        mainPanel.add(adminButton);
        mainPanel.add(developedByLabel);

        // Frame
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(350, 250);
        frame.setResizable(false);
        frame.setLocation(520,200);
        frame.setIconImage(logo.getImage());
        frame.add(mainPanel);
        frame.setVisible(true);
        this.onClickUserButton();
        this.onClickAdminButton();
    }

    public void onClickUserButton(){
        userButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 80, 15));
                frame.setSize(350, 430);
                frame.setLocation(520, 125);
                mainPanel.remove(logoLabel);
                mainPanel.remove(userButton);
                mainPanel.remove(adminButton);
                mainPanel.remove(titleLabel);
                mainPanel.remove(developedByLabel);
                mainPanel.add(titleLabel);
                signInLabel.setText("User Sign In");
                mainPanel.add(signInLabel);
                mainPanel.add(emailIdLabel);
                mainPanel.add(emailIdEntry);
                mainPanel.add(passWordLabel);
                mainPanel.add(passWordEntry);
                mainPanel.add(submitButton);
                mainPanel.add(forgotButton);
                mainPanel.add(registerButton);
                mainPanel.add(developedByLabel);
                mainPanel.revalidate();

                submitButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        emailMatcher = emailPattern.matcher(emailIdEntry.getText());
                        if ((!emailMatcher.matches()) || (passWordEntry.getText().equals(""))){
                            JOptionPane.showMessageDialog(null, "Invalid Credentials", "Try Again", JOptionPane.INFORMATION_MESSAGE);
                        }
                        else{
                            SignIn signIn = new SignIn(emailIdEntry.getText(), passWordEntry.getText());
                            if (!signIn.validateUser()){
                                JOptionPane.showMessageDialog(null, "Invalid Credentials", "Try Again", JOptionPane.INFORMATION_MESSAGE);
                            }
                            else{
                                frame.dispose();
                                home.setVisible(true);
                            }
                        }
                    }
                });


            }
        });
    }
    public void onClickAdminButton() {
        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 80, 15));
                frame.setSize(350, 430);
                frame.setLocation(520, 125);
                mainPanel.remove(logoLabel);
                mainPanel.remove(userButton);
                mainPanel.remove(adminButton);
                mainPanel.remove(titleLabel);
                mainPanel.remove(developedByLabel);
                mainPanel.add(titleLabel);
                signInLabel.setText("Admin Sign In");
                mainPanel.add(signInLabel);
                mainPanel.add(emailIdLabel);
                mainPanel.add(emailIdEntry);
                mainPanel.add(passWordLabel);
                mainPanel.add(passWordEntry);
                mainPanel.add(submitButton);
                mainPanel.add(forgotButton);
                registerButton.setText("New Admin?? Click here");
                mainPanel.add(registerButton);
                mainPanel.add(developedByLabel);
                mainPanel.revalidate();
            }
        });
    }
}
