package com.gui.sign;

import java.io.*;
import java.util.Scanner;

public class Credentials{
    // Data Members
    private String fullName, adminName, dateOfBirth, emailId, mobileNo, passWord, userName, error;

    private int adminId;

    // Constructors
    public void Credentials(){

    }
    // Getters
    public String getFullName(){
        return this.fullName;
    }

    public String getAdminName(){
        return this.adminName;
    }

    public String getDOB(){
        return this.dateOfBirth;
    }

    public String getEmail(){
        return this.emailId;
    }

    public String getMobile(){
        return this.mobileNo;
    }

    public String getPassWord(){
        return this.passWord;
    }

    public String getUserName(){
        return this.userName;
    }

    public int getAdminID(){
        return this.adminId;
    }

    // Setter
    public void setFullName(String fullName){
        this.fullName = fullName;
    }

    public void setAdminName(String fullName){
        this.fullName = fullName;
    }

    public void setDOB(String fullName){
        this.fullName = fullName;
    }

    public void setEmail(String fullName){
        this.fullName = fullName;
    }

    public void setMobile(String fullName){
        this.fullName = fullName;
    }

    public void setPassWord(String fullName){
        this.fullName = fullName;
    }

    public void setUserName(String fullName){
        this.fullName = fullName;
    }

    public void setAdminId(String fullName){
        this.fullName = fullName;
    }

    // User Defined methods
    public void writeDetails(String fullName, String dateOfBirth, String emailId, String mobileNo, String userName, String passWord) throws IOException {
        try {
            File credentialsUser = new File("D:\\Object Oriented Programming\\Mini Project\\AirlineReservationSystem\\files\\credentialsUser.txt");
            FileWriter fileWriter = new FileWriter(credentialsUser, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(userName + ":" + passWord + ":" + fullName + ":" + dateOfBirth + ":" + emailId + ":" + mobileNo);
            bufferedWriter.newLine();
            bufferedWriter.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void writeDetails(String fullName, String dateOfBirth, String emailId, String mobileNo, int adminId, String passWord) throws IOException {
        try {
            File credentialsUser = new File("D:\\Object Oriented Programming\\Mini Project\\AirlineReservationSystem\\files\\credentialsUser.txt");
            FileWriter fileWriter = new FileWriter(credentialsUser, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(fullName + ":" + dateOfBirth + ":" + emailId + ":" + mobileNo);
            bufferedWriter.newLine();
            bufferedWriter.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void readDetails(String userName, String passWord){
        File file = new File("D:\\Object Oriented Programming\\Mini Project\\AirlineReservationSystem\\files\\credentialsUser.txt");
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] details = line.split(":");
                if (userName.equals(details[4]) && passWord.equals(details[1])){
                   this.userName = details[0];
                   this.passWord = details[1];
                   this.fullName = details[2];
                   this.dateOfBirth = details[3];
                   this.emailId = details[4];
                   this.mobileNo = details[5];
                }
            }
            this.error = null;
        }
        catch(FileNotFoundException e) {
            this.error = e.getMessage();
        }
    }

//    public void getDetails(String emailId){
//        File file = new File("D:\\Object Oriented Programming\\Mini Project\\AirlineReservationSystem\\files\\credentialsUser.txt");
//        try{
//
//        }
//    }
    public String readDetails(String emailId) {
        File file = new File("D:\\Object Oriented Programming\\Mini Project\\AirlineReservationSystem\\files\\credentialsUser.txt");
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] details = line.split(":");
                if (emailId.equals(details[4])){
                    return details[1];
                }
            }
            this.error = null;
        }
        catch(FileNotFoundException e) {
            this.error = e.getMessage();
        }
        return "Null";
    }
}