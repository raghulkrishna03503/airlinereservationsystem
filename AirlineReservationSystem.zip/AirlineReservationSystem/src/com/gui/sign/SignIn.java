package com.gui.sign;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class SignIn extends Credentials{
    private String emailId, passWord;

    public SignIn(String userName, String passWord) {
        this.emailId = userName;
        this.passWord = passWord;
    }

    public SignIn(String emailId) {
        this.emailId = emailId;
    }

    public boolean validateUser(){
        super.readDetails(this.emailId, this.passWord);
        if (this.emailId.equals(super.getEmail()) && this.passWord.equals(super.getPassWord())){
            return true;
        }
        else{
            return false;
        }
    }

    public boolean validateAdmin(){
        return true;
    }
}
