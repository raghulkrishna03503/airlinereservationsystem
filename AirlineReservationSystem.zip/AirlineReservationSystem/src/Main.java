import com.gui.GUI;
import com.gui.sign.Credentials;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        GUI gui = new GUI();
    }
}